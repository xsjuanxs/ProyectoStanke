package com.gameshop.repository;

import com.gameshop.model.Juego;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/** CRUD de la tabla "juegos" con JdbcTemplate: aquí vive TODO el SQL. */
@Repository
public class JuegoRepository {

    private final JdbcTemplate jdbc;                     // parámetros con ?
    private final NamedParameterJdbcTemplate namedJdbc;  // parámetros con :nombre

    // Spring Boot crea los dos objetos y los inyecta por el constructor
    public JuegoRepository(JdbcTemplate jdbc, NamedParameterJdbcTemplate namedJdbc) {
        this.jdbc = jdbc;
        this.namedJdbc = namedJdbc;
    }

    // Columnas explícitas (no SELECT *): si la tabla cambia, el error aparece aquí
    private static final String COLUMNAS =
            "id, titulo, id_categoria, precio, desarrollador, anio";

    // RowMapper: convierte UNA fila del ResultSet en UN objeto Juego
    private static final RowMapper<Juego> MAPPER = (rs, rowNum) -> {
        Juego j = new Juego();
        j.setId(rs.getInt("id"));
        j.setTitulo(rs.getString("titulo"));
        j.setIdCategoria(rs.getInt("id_categoria"));
        j.setPrecio(rs.getBigDecimal("precio"));
        j.setDesarrollador(rs.getString("desarrollador"));
        j.setAnio(rs.getObject("anio", Integer.class));  // getInt convertiría NULL en 0
        return j;
    };

    // ── READ ───────────────────────────────────────────────────────────

    public List<Juego> findAll() {
        return jdbc.query("SELECT " + COLUMNAS + " FROM juegos ORDER BY id", MAPPER);
    }

    /** Optional vacío si no existe (sin try/catch: query devuelve una lista). */
    public Optional<Juego> findById(int id) {
        return jdbc.query("SELECT " + COLUMNAS + " FROM juegos WHERE id = ?", MAPPER, id)
                   .stream()
                   .findFirst();
    }

    public List<Juego> findByCategoria(int idCategoria) {
        return jdbc.query("SELECT " + COLUMNAS
                        + " FROM juegos WHERE id_categoria = ? ORDER BY titulo",
                          MAPPER, idCategoria);
    }

    // ── CREATE ─────────────────────────────────────────────────────────

    /** INSERT y devuelve el juego con el id que generó PostgreSQL. */
    public Juego save(Juego juego) {
        String sql = """
                INSERT INTO juegos (titulo, id_categoria, precio, desarrollador, anio)
                VALUES (:titulo, :idCategoria, :precio, :desarrollador, :anio)
                """;
        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("titulo",        juego.getTitulo())
                .addValue("idCategoria",   juego.getIdCategoria())
                .addValue("precio",        juego.getPrecio())
                .addValue("desarrollador", juego.getDesarrollador())
                .addValue("anio",          juego.getAnio());

        KeyHolder keyHolder = new GeneratedKeyHolder();
        // "id" = nombre EXACTO de la llave primaria en PostgreSQL
        namedJdbc.update(sql, params, keyHolder, new String[]{"id"});
        juego.setId(keyHolder.getKey().intValue());
        return juego;
    }

    // ── UPDATE ─────────────────────────────────────────────────────────

    /** true si actualizó una fila; false si el id no existe. */
    public boolean update(int id, Juego juego) {
        String sql = """
                UPDATE juegos
                   SET titulo = :titulo, id_categoria = :idCategoria, precio = :precio,
                       desarrollador = :desarrollador, anio = :anio
                 WHERE id = :id
                """;
        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("titulo",        juego.getTitulo())
                .addValue("idCategoria",   juego.getIdCategoria())
                .addValue("precio",        juego.getPrecio())
                .addValue("desarrollador", juego.getDesarrollador())
                .addValue("anio",          juego.getAnio())
                .addValue("id",            id);
        return namedJdbc.update(sql, params) > 0;
    }

    // ── DELETE ─────────────────────────────────────────────────────────

    /** true si borró una fila; false si el id no existe. */
    public boolean delete(int id) {
        return jdbc.update("DELETE FROM juegos WHERE id = ?", id) > 0;
    }
}
