package com.gameshop.model;

import java.math.BigDecimal;

/**
 * Una fila de la tabla "juegos".
 *
 *   id            SERIAL PRIMARY KEY
 *   titulo        VARCHAR(100) NOT NULL
 *   id_categoria  INTEGER NOT NULL → categorias(id)
 *   precio        NUMERIC(8,2) NOT NULL, >= 0
 *   desarrollador VARCHAR(80)        (puede ser NULL)
 *   anio          INTEGER            (puede ser NULL)
 *
 * Precio en BigDecimal: NUMERIC es exacto y double no (0.1 + 0.2 ≠ 0.3).
 * Año en Integer (no int): así puede valer null, igual que en la tabla.
 */
public class Juego {

    private int        id;
    private String     titulo;
    private int        idCategoria;     // columna id_categoria
    private BigDecimal precio;
    private String     desarrollador;
    private Integer    anio;

    // Constructor vacío: lo necesita Spring para convertir el JSON del @RequestBody
    public Juego() { }

    public int getId()                           { return id; }
    public void setId(int id)                    { this.id = id; }

    public String getTitulo()                    { return titulo; }
    public void setTitulo(String titulo)         { this.titulo = titulo; }

    public int getIdCategoria()                  { return idCategoria; }
    public void setIdCategoria(int idCategoria)  { this.idCategoria = idCategoria; }

    public BigDecimal getPrecio()                { return precio; }
    public void setPrecio(BigDecimal precio)     { this.precio = precio; }

    public String getDesarrollador()             { return desarrollador; }
    public void setDesarrollador(String d)       { this.desarrollador = d; }

    public Integer getAnio()                     { return anio; }
    public void setAnio(Integer anio)            { this.anio = anio; }
}
