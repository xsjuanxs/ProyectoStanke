package com.gameshop.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.gameshop.model.Categoria;
@Repository
public class CategoriaRepository {
 
    private final JdbcTemplate jdbc;                     // parámetros con ?
    private final NamedParameterJdbcTemplate namedJdbc;  // parámetros con :nombre

    // Spring Boot crea los dos objetos y los inyecta por el constructor
    public CategoriaRepository(JdbcTemplate jdbc, NamedParameterJdbcTemplate namedJdbc) {
        this.jdbc = jdbc;
        this.namedJdbc = namedJdbc;
    }

        private static final String COLUMNAS =
            "id, nombre";

    // RowMapper: convierte UNA fila del ResultSet en UN objeto Juego
    private static final RowMapper<Categoria> MAPPER = (rs, rowNum) -> {
        Categoria c = new Categoria();
        c.setId(rs.getInt("id"));
        c.setNombre(rs.getString("nombre"));
        return c;
    };

    // ── READ ───────────────────────────────────────────────────────────

    public List<Categoria> findAll() {
        return jdbc.query("SELECT " + COLUMNAS + " FROM categorias ORDER BY id", MAPPER);
    }

    /** Optional vacío si no existe (sin try/catch: query devuelve una lista). */
    public Optional<Categoria> findById(int id) {
        return jdbc.query("SELECT " + COLUMNAS + " FROM categorias WHERE id = ?", MAPPER, id)
                   .stream()
                   .findFirst();
    }

    /**public List<Categoria> findByCategoria(int idCategoria) {
        return jdbc.query("SELECT " + COLUMNAS
                        + " FROM juegos WHERE id_categoria = ? ORDER BY titulo",
                          MAPPER, idCategoria);
    }*/

    // ── CREATE ─────────────────────────────────────────────────────────

    /** INSERT y devuelve el juego con el id que generó PostgreSQL. */
    public Categoria save(Categoria categoria) {
        String sql = """
                INSERT INTO categorias (nombre)
                VALUES (:nombre)
                """;
        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("nombre",        categoria.getNombre());

        KeyHolder keyHolder = new GeneratedKeyHolder();
        // "id" = nombre EXACTO de la llave primaria en PostgreSQL
        namedJdbc.update(sql, params, keyHolder, new String[]{"id"});
        categoria.setId(keyHolder.getKey().intValue());
        return categoria;
    }

    // ── UPDATE ─────────────────────────────────────────────────────────

    /** true si actualizó una fila; false si el id no existe. */
    public boolean update(int id, Categoria categoria) {
        String sql = """
                UPDATE Categorias
                   SET nombre = :nombre
                 WHERE id = :id
                """;
        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("nombre",        categoria.getNombre())
                .addValue("id",            id);
        return namedJdbc.update(sql, params) > 0;
    }

    // ── DELETE ─────────────────────────────────────────────────────────

    /** true si borró una fila; false si el id no existe. */
    public boolean delete(int id) {
        return jdbc.update("DELETE FROM categorias WHERE id = ?", id) > 0;
    }
    
}
