package com.gameshop.repository;

import com.gameshop.model.FacturaRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/** Llama al procedimiento pr_registrar_factura (sql/02_procedimiento_facturas.sql). */
@Repository
public class FacturaRepository {

    private final JdbcTemplate jdbc;

    public FacturaRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /** El parámetro INOUT hace que el CALL devuelva una fila con el id de la factura. */
    public int registrar(FacturaRequest f) {
        return jdbc.queryForObject("CALL pr_registrar_factura(?, ?, ?, NULL)",
                                   Integer.class, f.idCliente(), f.idJuego(), f.cantidad());
    }
}
