package com.gameshop.controller;

import com.gameshop.model.Juego;
import com.gameshop.repository.JuegoRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Endpoints REST de "juegos":
 *   GET    /juegos                      → lista todos           200
 *   GET    /juegos/{id}                 → uno por id            200 · 404
 *   GET    /juegos/categoria/{id}       → los de una categoría  200
 *   POST   /juegos          + JSON      → crea                  201
 *   PUT    /juegos/{id}     + JSON      → actualiza             200 · 404
 *   DELETE /juegos/{id}                 → elimina               204 · 404
 */
@RestController
@RequestMapping("/juegos")
public class JuegoController {

    private final JuegoRepository repo;

    public JuegoController(JuegoRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Juego> listar() {
        return repo.findAll();
    }

    // @PathVariable("id") con el nombre explícito: funciona igual en IntelliJ y en Maven
    @GetMapping("/{id}")
    public ResponseEntity<Juego> buscar(@PathVariable("id") int id) {
        return repo.findById(id)
                   .map(ResponseEntity::ok)
                   .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/categoria/{idCategoria}")
    public List<Juego> porCategoria(@PathVariable("idCategoria") int idCategoria) {
        return repo.findByCategoria(idCategoria);
    }

    @PostMapping
    public ResponseEntity<Juego> crear(@RequestBody Juego juego) {
        return ResponseEntity.status(HttpStatus.CREATED).body(repo.save(juego));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> actualizar(@PathVariable("id") int id,
                                           @RequestBody Juego juego) {
        return repo.update(id, juego)
                ? ResponseEntity.ok().build()
                : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable("id") int id) {
        return repo.delete(id)
                ? ResponseEntity.noContent().build()
                : ResponseEntity.notFound().build();
    }
}
