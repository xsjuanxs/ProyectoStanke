package com.gameshop.model;

/**
 * Cuerpo JSON de POST /facturas:  {"idCliente": 1, "idJuego": 4, "cantidad": 2}
 * Un record de Java 17: constructor, getters, equals y toString automáticos.
 */
public record FacturaRequest(int idCliente, int idJuego, int cantidad) { }
