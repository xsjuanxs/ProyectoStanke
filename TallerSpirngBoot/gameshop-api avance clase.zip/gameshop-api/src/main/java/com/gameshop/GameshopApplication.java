package com.gameshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Punto de entrada. En IntelliJ: clic en el ▶ verde junto a main.
 * Luego abran http://localhost:8080/juegos
 */
@SpringBootApplication
public class GameshopApplication {

    public static void main(String[] args) {
        SpringApplication.run(GameshopApplication.class, args);
    }
}
