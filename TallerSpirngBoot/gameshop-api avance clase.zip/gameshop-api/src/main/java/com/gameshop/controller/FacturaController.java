package com.gameshop.controller;

import com.gameshop.model.FacturaRequest;
import com.gameshop.repository.FacturaRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 *   POST /facturas  + {"idCliente":1,"idJuego":4,"cantidad":2}
 *        → 201 {"idFactura": 21}
 *        → 400 {"error": "El cliente 99 no existe"}   (RAISE EXCEPTION del procedimiento)
 */
@RestController
@RequestMapping("/facturas")
public class FacturaController {

    private final FacturaRepository repo;

    public FacturaController(FacturaRepository repo) {
        this.repo = repo;
    }

    @PostMapping
    public ResponseEntity<Map<String, Integer>> registrar(
            @RequestBody FacturaRequest factura) {
        int id = repo.registrar(factura);
        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of("idFactura", id));
    }
}
