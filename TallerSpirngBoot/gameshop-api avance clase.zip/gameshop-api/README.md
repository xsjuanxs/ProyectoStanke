# GameShop API — Spring Boot + JdbcTemplate

API REST de ejemplo para BD Avanzadas (Sesión 1). CRUD de `juegos`, manejo de errores de PostgreSQL
y un ejemplo de cómo llamar un procedimiento almacenado.

## 1. Base de datos (pgAdmin)
1. Crear la base `gameshop`.
2. Query Tool sobre `gameshop` → abrir `sql/gameshop_db.sql` → **F5**.
   Debe mostrar: categorias 5 · juegos 15 · clientes 8 · facturas 20.
3. (Opcional, sección 8 de la guía) ejecutar `sql/02_procedimiento_facturas.sql`.

> La columna del año se llama `anio`. Si tienen una versión vieja con `año`:
> `ALTER TABLE juegos RENAME COLUMN "año" TO anio;`

## 2. Abrir en Visual Studio Code
1. Instalar las extensiones **Extension Pack for Java** y **Spring Boot Extension Pack**.
2. Tener un JDK 17 o superior (`java -version`). Si no: Ctrl+Shift+P → *Java: Configure Java Runtime*.
3. **File → Open Folder** → esta carpeta (la que contiene `pom.xml`) → *Yes, I trust the authors*.
4. Esperar a que la barra inferior diga **Java: Ready** (descarga las dependencias; no hace falta instalar Maven).
   Si queda código en rojo: Ctrl+Shift+P → *Java: Clean Java Language Server Workspace*.

## 3. Configurar y ejecutar
1. Editar `src/main/resources/application.properties`: puerto de PostgreSQL, usuario y contraseña.
2. Abrir `GameshopApplication.java` → clic en **Run** encima de `main`
   (o panel *Spring Boot Dashboard* → ▶). En la terminal: `Tomcat started on port 8080`.
3. Navegador: http://localhost:8080/juegos

También se puede ejecutar por terminal (con Maven instalado): `mvn spring-boot:run`

## Endpoints
| Método | URL | Respuesta |
|---|---|---|
| GET | /juegos | 200 + lista |
| GET | /juegos/{id} | 200 · 404 |
| GET | /juegos/categoria/{idCategoria} | 200 + lista |
| POST | /juegos + JSON | 201 + juego con id |
| PUT | /juegos/{id} + JSON | 200 · 404 |
| DELETE | /juegos/{id} | 204 · 404 |
| POST | /facturas + JSON | 201 · 400 (llama a `pr_registrar_factura`) |

Errores de restricciones de la base (FK, CHECK, NOT NULL) → **409** con el mensaje de PostgreSQL.

Ejemplo de JSON:
```json
{"titulo":"Hades","idCategoria":1,"precio":24.99,"desarrollador":"Supergiant Games","anio":2020}
```

## Versiones
Spring Boot 4.1.x · Java 17+ · PostgreSQL 14+. El código también funciona con Spring Boot 3.x
(en ese caso, en el `pom.xml` el starter web se llama `spring-boot-starter-web`).
