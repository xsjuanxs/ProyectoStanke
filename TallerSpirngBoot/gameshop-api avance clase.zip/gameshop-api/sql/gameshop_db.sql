-- ============================================================
--  GameShop — Base de datos de ejemplo del curso
--  Versión para Spring Boot: la columna del año se llama "anio" (sin ñ).
--  Regla práctica: en nombres de tablas y columnas, nada de tildes ni ñ.
--
--  Motor: PostgreSQL 14+
--  Para correr: en pgAdmin, sobre la base gameshop, ejecutar el archivo completo (F5)
-- ============================================================

-- ── Limpiar si ya existen ─────────────────────────────────────────────────
DROP TABLE IF EXISTS facturas   CASCADE;
DROP TABLE IF EXISTS clientes   CASCADE;
DROP TABLE IF EXISTS juegos     CASCADE;
DROP TABLE IF EXISTS categorias CASCADE;


-- ── TABLAS ────────────────────────────────────────────────────────────────

CREATE TABLE categorias (
    id     SERIAL       PRIMARY KEY,
    nombre VARCHAR(50)  NOT NULL UNIQUE
);

CREATE TABLE juegos (
    id           SERIAL          PRIMARY KEY,
    titulo       VARCHAR(100)    NOT NULL,
    id_categoria INTEGER         NOT NULL REFERENCES categorias(id),
    precio       NUMERIC(8, 2)   NOT NULL CHECK (precio >= 0),
    desarrollador VARCHAR(80),
    anio          INTEGER
);

CREATE TABLE clientes (
    id               SERIAL       PRIMARY KEY,
    nombre           VARCHAR(100) NOT NULL,
    pais             VARCHAR(50)  NOT NULL,
    fecha_registro   DATE         NOT NULL DEFAULT CURRENT_DATE
);

CREATE TABLE facturas (
    id          SERIAL      PRIMARY KEY,
    id_cliente  INTEGER     NOT NULL REFERENCES clientes(id),
    id_juego    INTEGER     NOT NULL REFERENCES juegos(id),
    fecha       DATE        NOT NULL,
    cantidad    INTEGER     NOT NULL DEFAULT 1 CHECK (cantidad > 0)
);


-- ── DATOS ─────────────────────────────────────────────────────────────────

INSERT INTO categorias (nombre) VALUES
    ('Acción'),
    ('RPG'),
    ('Deportes'),
    ('Estrategia'),
    ('Simulación');

--  id_categoria:  1=Acción · 2=RPG · 3=Deportes · 4=Estrategia · 5=Simulación
INSERT INTO juegos (titulo, id_categoria, precio, desarrollador, anio) VALUES
    ('God of War',                    1, 59.99, 'Santa Monica Studio',  2018),
    ('The Last of Us Part I',         1, 39.99, 'Naughty Dog',          2013),
    ('Uncharted 4',                   1, 19.99, 'Naughty Dog',          2016),
    ('Elden Ring',                    2, 59.99, 'FromSoftware',         2022),
    ('The Witcher 3',                 2, 29.99, 'CD Projekt',           2015),
    ('Cyberpunk 2077',                2, 49.99, 'CD Projekt',           2020),
    ('FIFA 24',                       3, 69.99, 'EA Sports',            2023),
    ('NBA 2K24',                      3, 59.99, '2K Games',             2023),
    ('eFootball',                     3,  0.00, 'Konami',               2021),
    ('Civilization VI',               4, 39.99, 'Firaxis Games',        2016),
    ('StarCraft II',                  4,  0.00, 'Blizzard',             2010),
    ('Age of Empires IV',             4, 49.99, 'Relic Entertainment',  2021),
    ('The Sims 4',                    5,  0.00, 'Maxis',                2014),
    ('Microsoft Flight Simulator',    5,119.99, 'Asobo Studio',         2020),
    ('Cities: Skylines',              5, 29.99, 'Colossal Order',       2015);

INSERT INTO clientes (nombre, pais, fecha_registro) VALUES
    ('Ana García',       'Colombia',  '2022-03-15'),
    ('Luis Pérez',       'México',    '2021-07-20'),
    ('María Rodríguez',  'Colombia',  '2023-01-10'),
    ('Carlos Martínez',  'Argentina', '2020-11-05'),
    ('Sofía López',      'Colombia',  '2022-08-30'),
    ('Andrés Torres',    'México',    '2023-04-12'),
    ('Valentina Díaz',   'Chile',     '2021-09-18'),
    ('Diego Herrera',    'Colombia',  '2022-12-01');

--  Distribución:
--    Ana (1)       → God of War, Elden Ring, StarCraft II
--    Luis (2)      → FIFA 24, NBA 2K24, Age of Empires IV
--    María (3)     → The Witcher 3, Cyberpunk 2077, NBA 2K24
--    Carlos (4)    → God of War, Civilization VI
--    Sofía (5)     → FIFA 24, Microsoft Flight Simulator, God of War
--    Andrés (6)    → Elden Ring, The Witcher 3
--    Valentina (7) → The Last of Us, Uncharted 4
--    Diego (8)     → God of War, FIFA 24
INSERT INTO facturas (id_cliente, id_juego, fecha, cantidad) VALUES
    (1,  1, '2023-01-15', 1),   -- Ana       → God of War
    (1,  4, '2023-02-10', 1),   -- Ana       → Elden Ring
    (2,  7, '2023-01-20', 1),   -- Luis      → FIFA 24
    (2,  8, '2023-03-05', 1),   -- Luis      → NBA 2K24
    (3,  5, '2023-01-25', 1),   -- María     → The Witcher 3
    (3,  6, '2023-04-12', 1),   -- María     → Cyberpunk 2077
    (4,  1, '2022-12-20', 1),   -- Carlos    → God of War
    (4, 10, '2023-05-08', 1),   -- Carlos    → Civilization VI
    (5,  7, '2023-06-15', 1),   -- Sofía     → FIFA 24
    (5, 14, '2023-07-01', 1),   -- Sofía     → Microsoft Flight Simulator
    (6,  4, '2023-08-10', 1),   -- Andrés    → Elden Ring
    (6,  5, '2023-09-22', 1),   -- Andrés    → The Witcher 3
    (7,  2, '2023-10-05', 1),   -- Valentina → The Last of Us
    (7,  3, '2023-11-18', 1),   -- Valentina → Uncharted 4
    (8,  1, '2023-12-25', 1),   -- Diego     → God of War
    (8,  7, '2024-01-10', 1),   -- Diego     → FIFA 24
    (1, 11, '2024-01-20', 1),   -- Ana       → StarCraft II
    (3,  8, '2024-02-14', 1),   -- María     → NBA 2K24
    (5,  1, '2024-03-01', 1),   -- Sofía     → God of War
    (2, 12, '2024-03-15', 1);   -- Luis      → Age of Empires IV


-- ── VERIFICACIÓN RÁPIDA ───────────────────────────────────────────────────
SELECT 'categorias' AS tabla, COUNT(*) AS filas FROM categorias
UNION ALL
SELECT 'juegos',   COUNT(*) FROM juegos
UNION ALL
SELECT 'clientes', COUNT(*) FROM clientes
UNION ALL
SELECT 'facturas', COUNT(*) FROM facturas;

-- Resultado esperado:
--  tabla       | filas
-- -------------+-------
--  categorias  |     5
--  juegos      |    15
--  clientes    |     8
--  facturas    |    20
