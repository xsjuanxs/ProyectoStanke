-- ============================================================
--  GameShop — Procedimiento para registrar una venta
--  (para la diapositiva "Llamar un procedimiento desde Spring Boot")
--  Ejecutar DESPUÉS de gameshop_db.sql
-- ============================================================

CREATE OR REPLACE PROCEDURE pr_registrar_factura(
       p_cliente  INT,
       p_juego    INT,
       p_cantidad INT,
       INOUT p_factura INT DEFAULT NULL)        -- devuelve el id de la factura
LANGUAGE plpgsql AS $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM clientes WHERE id = p_cliente) THEN
        RAISE EXCEPTION 'El cliente % no existe', p_cliente;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM juegos WHERE id = p_juego) THEN
        RAISE EXCEPTION 'El juego % no existe', p_juego;
    END IF;
    IF p_cantidad IS NULL OR p_cantidad <= 0 THEN
        RAISE EXCEPTION 'La cantidad debe ser mayor que cero';
    END IF;

    INSERT INTO facturas (id_cliente, id_juego, fecha, cantidad)
    VALUES (p_cliente, p_juego, CURRENT_DATE, p_cantidad)
    RETURNING id INTO p_factura;
END; $$;

-- Prueba en pgAdmin:
-- CALL pr_registrar_factura(1, 4, 2);     -- devuelve p_factura = 21
-- CALL pr_registrar_factura(99, 4, 1);    -- ERROR: El cliente 99 no existe
